public enum Wedding {
 ODIN("Ваша следующая свадьба Ситцевая"),
    DWA(" Ваша следующая свадьба Бумажная "),
    TRI(" Ваша следующая свадьба Кожаная"),
    CHETYRE(" Ваша следующая свадьба Льняная"),
    PJT(" Ваша следующая свадьба Деревянная "),
    SHEST(" Ваша следующая свадьба Чугунная "),
    SEM ("Ваша следующая свадьба Медная"),
    WOSEM("Ваша следующая свадьба Жестяная "),
    DEVET("Ваша следующая свадьба Фаянсовая"),
    DESET("Ваша следующая свадьба Оловянная");

 private final String description;

    public String getDescription() {
        return description;
    }
    Wedding(String description){
        this.description = description;

    }
}
