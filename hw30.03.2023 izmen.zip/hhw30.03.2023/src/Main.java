import java.util.Scanner;

public class Main {
    // Пользователь вводит, сколько лет он состоит в браке
    // Программа должна вывести, какая годовщина свадьбы будет у пользователя следующей
    // (бумажная, ситцевая, чугунная, серебряная и.д.). Не обязательно указывать все годовщины, достаточно 10-15.


    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Сколько лет вы в Браке");
        int wedNum = scn.nextInt();
        wedNum = wedNum +1;
        String message = switch (wedNum) {
            case 1 -> concat(Wedding.ODIN);
            case 2 -> concat(Wedding.DWA);
            case 3 -> concat(Wedding.TRI);
            case 4 -> concat(Wedding.CHETYRE);
            case 5 -> concat(Wedding.PJT);
            case 6 -> concat(Wedding.SHEST);
            case 7 -> concat(Wedding.SEM);
            case 8 -> concat(Wedding.WOSEM);
            case 9 -> concat(Wedding.DEVET);
            case 10 -> concat(Wedding.DESET);
            default -> "Такого значения нет";
        };
        System.out.println(message);

    }

    public static String concat(Wedding wed) {
        return wed.getDescription();

    }
}